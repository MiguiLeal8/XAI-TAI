
# D1 — TXAI Experiments and Documentation

This directory contains the material for **Deliverable D1**, including Jupyter notebooks, generated reports, and supporting documentation related to **Trustworthy / Explainable AI (TXAI)** experiments.

---

## Directory Structure
```text
D1/
├── TXAI_I1_SHAP.ipynb
├── TXAI_I2_EXFS.ipynb
├── TXAI_I3_EXFS.ipynb
└── docs/
    ├── TXAI-D1-I1_I2-Leal_Bulleddu.pdf
    ├── TXAI-D1-I3-Leal_Bulleddu.pdf
    ├── TXAI_I1_SHAP.html
    ├── TXAI_I2_EXFS.html
    ├── TXAI_I3_EXFS.html
```

## Notebooks

- **`TXAI_I1_SHAP.ipynb`**  
  Implementation and analysis of **SHAP-based explainability** techniques.  
  Focuses on feature attribution and model interpretability.

- **`TXAI_I2_EXFS.ipynb`**  
  Experiments using **EXFS (Explainable Feature Selection)** methods.  
  Includes feature importance analysis and explanatory insights.

- **`TXAI_I3_EXFS.ipynb`**  
  Extended or alternative EXFS experiments, comparisons, and results.

Each notebook is self-contained and includes:
- Data loading and preprocessing  
- Model training  
- Explainability analysis  
- Visualizations and outputs  

---

## Documentation (`docs/`)

### Reports
- **`TXAI-D1-I1_I2-Leal_Bulleddu.pdf`**  
  Final report for **I1 (SHAP)** and **I2 (EXFS)** activities.

- **`TXAI-D1-I3-Leal_Bulleddu.pdf`**  
  Final report for **I3 (EXFS)** activities.
---

### HTML Exports
- **`TXAI_I1_SHAP.html`**
- **`TXAI_I2_EXFS.html`**
- **`TXAI_I3_EXFS.html`**

These are static HTML exports of the notebooks, intended for **easy viewing without requiring Jupyter**.

---

##  How to Use

1. **Run notebooks**  
   Open the `.ipynb` files using Jupyter Notebook or JupyterLab.

2. **Read results quickly**  
   Open the `.html` files in `docs/` with any web browser.

3. **Consult final documentation**  
   Refer to the `.pdf` files for structured explanations and conclusions.

---

##  Notes

- This deliverable focuses on **explainability and trustworthiness**, not model performance alone.
- All materials are organized to ensure **reproducibility and clarity**.

---

##  Authors

- Miguel Leal Fernandez (miguel.leal@rai.usc.es)
- Gian Paolo Bulleddu (gianpaolo.bulleddu@rai.usc.es)